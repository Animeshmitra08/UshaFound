// import React from 'react'
import logo from "../assets/logo/uf.png";
// import bgimg1 from "../assets/images/children-6685385_1280.jpg";

// const Footer = () => {
//   return (
//    <>
//    <footer className="text-white relative min-h-screen">
//         <div className="absolute inset-0 bg-fixed bg-cover bg-center bg-no-repeat h-full w-full" style={{backgroundImage: `url(${bgimg1})`}}></div>

//         <div className="absolute bg-[#023047b9] inset-0">

//             <div className="container mx-auto mb:pt-[8.5rem] pt-[5rem] px-4 mb:px-0">
//                 <div className="grid lg:grid-cols-3 grid-cols-1 gap-4">
                    
//                     <div className="mb-4">
//                         <div className="footer-widget logo-widget">
//                             <div className="widget-content">
//                                 <div className="footer-logo">
//                                     <a href="index.html"><img src={logo} alt="image_logo" className="w-[15rem] bg-white mb-4" /></a>
//                                 </div>
//                                 <div className="font-Kaushan_Script text-xl">Warmth & True Support For Needed People</div>

//                                 <ul className="social-links clearfix">
//                                     <li><a href="#"><span className="fab fa-facebook-f"></span></a></li>
//                                     <li><a href="#"><span className="fab fa-twitter"></span></a></li>
//                                     <li><a href="#"><span className="fab fa-vimeo-v"></span></a></li>
//                                     <li><a href="#"><span className="fab fa-instagram"></span></a></li>
//                                     <li><a href="#"><span className="fab fa-youtube"></span></a></li>
//                                 </ul>
//                             </div>
//                         </div>
//                     </div>


//                     <div className="mb-4 col-span-2">
//                         <div className="grid grid-cols-1 md:grid-cols-3 gap-2 px-3 justify-between items-start">

//                             <div className="">
//                                 <div className="footer-widget links-widget">
//                                     <div className="widget-content">
//                                         <h3 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">About Us</h3>
//                                         <ul>
//                                             <li><a href="#">Upcoming Events</a></li>
//                                             <li><a href="#">Latest Causes</a></li>
//                                             <li><a href="#">News Blog</a></li>
//                                             <li><a href="#">Contact Us</a></li>
//                                             <li><a href="#">Who We Are</a></li>
//                                             <li><a href="#">Connect With Us</a></li>
//                                         </ul>
//                                     </div>  
//                                 </div>
//                             </div>
                            
//                             <div className="column col-lg-4 col-md-4 col-sm-12">
//                                 <div className="footer-widget links-widget">
//                                     <div className="widget-content">
//                                         <h3 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">Our Partners</h3>
//                                         <ul>
//                                             <li><a href="#">Donate Kausid</a></li>
//                                             <li><a href="#">Save Our earth</a></li>
//                                             <li><a href="#">Water Shortages</a></li>
//                                             <li><a href="#">Recycle Better</a></li>
//                                             <li><a href="#">Plant Trees Welfare</a></li>
//                                         </ul>
//                                     </div>  
//                                 </div>
//                             </div>


//                             <div className="column col-lg-4 col-md-4 col-sm-12">
//                                 <div className="footer-widget links-widget">
//                                     <div className="widget-content">
//                                         <h3 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">Explore</h3>
//                                         <ul>
//                                             <li><a href="#">Adopt A Child</a></li>
//                                             <li><a href="#">Join Our Programs</a></li>
//                                             <li><a href="#">Food Crisis Looms</a></li>
//                                             <li><a href="#">Make Donation</a></li>
//                                             <li><a href="#">Press Releases</a></li>
//                                             <li><a href="#">Global Programs</a></li>
//                                         </ul>
//                                     </div>  
//                                 </div>
//                             </div>

//                         </div>
//                     </div>
                    
                    
//                     <div className="big-column col-lg-12 col-md-12 col-sm-12">
//                         <div className="row clearfix">
//                             <div className="column col-lg-4 col-md-12 col-sm-12">
//                                 <div className="footer-widget info-widget">
//                                     <div className="widget-content">
//                                         <h3 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">Contact Us</h3>
//                                         <ul className="contact-info">
//                                             <li>4291 Glenview Drive, Florence, MI 29501</li>
//                                             <li><a href="tel:812-070-3692"><span className="fa fa-phone-alt"></span> Phone 812-070-3692</a></li>
//                                             <li><a href="mailto:donations@example.org"><span className="fa fa-envelope-open"></span> donations@example.org</a></li>
//                                         </ul>
//                                     </div>  
//                                 </div>
//                             </div>

//                             {/* <div className="column col-lg-8 col-md-12 col-sm-12">
//                                 <div className="footer-widget info-widget">
//                                     <div className="widget-content">
//                                         <h3>Subscribe Our Newsletter For Updates</h3>
//                                         <div className="newsletter-form">
//                                             <form method="post" action="contact.html">
//                                                 <div className="form-group clearfix">
//                                                     <input type="email" name="email" value="" placeholder="Enter Your Email" required=""/>
//                                                     <button type="submit" className="theme-btn newsletter-btn">Subscribe</button>
//                                                 </div>
//                                             </form>
//                                         </div>
//                                     </div>  
//                                 </div>
//                             </div> */}
//                         </div>
//                     </div>
                    
//                 </div>
                
//             </div>
//         </div>
        
//         <div className="relative text-center text-[#219ebc]">
//             <div className="container mx-auto">
//                 <div className="py-[5rem]">

//                     <div className="copyright">Copyrights (c) 2019 <a href="#">Kausid Charity &amp; Non-Profit Theme.</a> All rights reserved.</div>
//                 </div>
//             </div>
//         </div>
        
//     </footer>
//    </>
//   )
// }

// export default Footer


import { FaFacebook } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FaInstagram } from "react-icons/fa6";
import { FaYoutube } from "react-icons/fa6";
import { FaLinkedin } from "react-icons/fa";
import { FaLocationDot } from "react-icons/fa6";
import { FaPhone } from "react-icons/fa6";
import { IoMdMail } from "react-icons/io";
import { NavLink } from "react-router-dom";

import map from "../assets/images/image.png"

const Footer = () => {
  return (
    <>
        <footer className="bg-slate-100 border-t-2 border-t-slate-300 md:pt-[2rem] pt-[1rem]">
            <div className="mx-auto w-full max-w-screen-xl p-4 py-6 lg:py-8">
                <div className="md:flex md:flex-col md:justify-between">
                
                <div className="grid grid-cols-1 gap-8 sm:gap-6">
                    <div className="flex lg:flex-row flex-col justify-around">
                        <div className="mb-6">
                            <a href="#" className="flex flex-col">
                                <img src={logo} className="h-[6rem] w-[10rem] me-3" alt="Usha Foundation" />
                                <div className="font-Kaushan_Script text-xl">Warmth & True Support For Needed People</div>
                                <div className="flex mt-8 text-lg sm:text-2xl">
                                    <a href="#" className="text-gray-500 hover:text-gray-900 ">
                                        <FaFacebook/>
                                        <span className="sr-only">Facebook page</span>
                                    </a>
                                    <a href="#" className="text-gray-500 hover:text-gray-900  ms-5">
                                        <FaXTwitter/>
                                        <span className="sr-only">Twitter</span>
                                    </a>
                                    <a href="#" className="text-gray-500 hover:text-gray-900  ms-5">
                                        <FaInstagram/>
                                        <span className="sr-only">Instagram</span>
                                    </a>
                                    <a href="#" className="text-gray-500 hover:text-gray-900  ms-5">
                                        <FaYoutube/>
                                        <span className="sr-only">Youtube</span>
                                    </a>
                                    <a href="#" className="text-gray-500 hover:text-gray-900  ms-5">
                                        <FaLinkedin/>
                                        <span className="sr-only">LinkedIn</span>
                                    </a>
                                </div>
                            </a>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 px-3 justify-between items-start flex-1 lg:ml-[8rem] text-gray-900">

                             <div className="">
                                 <div className="footer-widget links-widget">
                                     <div className="widget-content">
                                         <h3 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">About Us</h3>
                                         <ul className="text-gray-500 flex flex-col gap-2">
                                             <li><NavLink to="/initiatives" className="hover:underline">Latest Causes</NavLink></li>
                                             <li><NavLink to="/contact" className="hover:underline">Connect With Us</NavLink></li>
                                         </ul>
                                     </div>  
                                 </div>
                             </div>

                             <div>
                                <h2 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">Contact Us</h2>
                                <ul className="text-gray-500 font-medium flex flex-col gap-4">
                                    <p className="flex gap-2 items-center"><FaLocationDot/>C/O Sai Baba Nursing Home, New Rajendra Nagar, Raipur (C.G.)</p>
                                    <a className="flex gap-2 items-center" ><FaPhone/>9644402050</a>
                                    <a className="flex gap-2 items-center hover:underline" href="ushafoundation45@gmail.com"><IoMdMail/>ushafoundation45@gmail.com</a>
                                </ul>                                
                            </div>

                            <div>
                                <h2 className="text-2xl font-semibold font-Playfair mb-6 relative before:absolute before:left-0 before:bottom-0 before:w-[30px] before:border-b-2 before:border-red-500">Location</h2>
                                <img src={map} alt="" />                              
                            </div>
                         </div>
                    </div>






                    
                    
                </div>
            </div>



            <hr className="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
            <div className="sm:flex sm:items-center sm:justify-between">
                <span className="text-sm text-gray-500 sm:text-center dark:text-gray-400"> &copy; {new Date().getFullYear()}
                <a href="#" className="hover:underline"> USHA FOUNDATION</a>. All Rights Reserved.
                </span>
                

                <div className="flex mt-4 sm:justify-center text-sm sm:mt-0 dark:text-gray-400">
                    Developed by 
                    <span className="font-semibold hover:underline ml-1 cursor-pointer">AON DIGICON LLP</span>
                </div>
            </div>
            </div>
        </footer>

    </>
  )
}

export default Footer